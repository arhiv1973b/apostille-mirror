// portal-enhancements.js
window.console && console.log("Portal enhancements loaded");