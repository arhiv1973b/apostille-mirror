// donate.js
window.console && console.log("Donate helpers loaded");